export * as RegisterAbi from "./RegisterAbi.json";
export * as NduAbi from "./NduAbi.json";
export * as ScanProductAbi from "./ScanProductAbi.json";
export * as NduTokenAbi from "./nduTokenAbi.json";
